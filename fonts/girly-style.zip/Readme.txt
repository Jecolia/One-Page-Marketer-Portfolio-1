"Girly Style Script Font" is a font created and copyrighted by AKRTYPE STUDIO.

It is free for personal and non-profit use. If you would like to use this font commercially and full alternates and ligatures, please visit https:http://bit.ly/3PMiPHo

To see Limited Price Bundle please visit: http://bit.ly/3NHkSdq

You are free to redistribute (not sell) this font as long as you include this ReadMe file with the font file and don't try to claim the font as free or as your own.
